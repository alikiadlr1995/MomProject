import FormPage from "@/components/Form";

export default FormPage;
