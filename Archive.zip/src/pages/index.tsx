import HomePage from "@/components/Home/index";

export default HomePage;
