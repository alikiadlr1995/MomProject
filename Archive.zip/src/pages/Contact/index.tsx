import ContactPage from "@/components/Contact";

export default ContactPage;
